#!/bin/bash
set -e

# Compile the code and test
g++ -std=c++17 -o test_deque ../code.cpp test.cpp -lpthread
./test_deque
