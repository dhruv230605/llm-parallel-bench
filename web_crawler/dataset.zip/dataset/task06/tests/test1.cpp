#include "../code.cpp"
#include <cassert>
#include <thread>
#include <vector>

void test_lock_free_deque() {
    LockFreeDeque<int> deque;
    deque.push_front(10);
    int value;
    assert(deque.pop_back(value) && value == 10);
    assert(!deque.pop_back(value)); // Should be empty now
}

int main() {
    const int num_threads = 4;
    std::vector<std::thread> threads;
    for (int i = 0; i < num_threads; ++i) {
        threads.emplace_back(test_lock_free_deque);
    }
    for (auto& t : threads) {
        t.join();
    }
    return 0;
}
