#include <atomic>
#include <memory>
#include <iostream>
#include <thread>

template<typename T>
class LockFreeDeque {
private:
    struct Node {
        T data;
        Node* next;
        Node(T value) : data(value), next(nullptr) {}
    };
    std::atomic<Node*> head;
    std::atomic<Node*> tail;

public:
    LockFreeDeque() : head(nullptr), tail(nullptr) {}

    void push_front(T value) {
        Node* new_node = new Node(value);
        Node* old_head = head.load();
        do {
            new_node->next = old_head;
        } while (!head.compare_exchange_weak(old_head, new_node));
    }

    bool pop_back(T& result) {
        Node* old_tail = tail.load();
        if (old_tail == nullptr) return false;
        if (tail.compare_exchange_strong(old_tail, old_tail->next)) {
            result = old_tail->data;
            delete old_tail;
            return true;
        }
        return false;
    }

    // Additional methods for steal() can be implemented similarly.
};

int main() {
    LockFreeDeque<int> deque;
    deque.push_front(1);
    int value;
    if (deque.pop_back(value)) {
        std::cout << "Popped: " << value << std::endl;
    } else {
        std::cout << "Deque is empty" << std::endl;
    }
    return 0;
}
