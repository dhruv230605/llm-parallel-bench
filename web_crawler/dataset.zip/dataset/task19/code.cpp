#include <atomic>
#include <thread>
#include <iostream>
#include <vector>

template<typename T>
class LockFreeQueue {
private:
    struct Node {
        T data;
        Node* next;
        Node(T value) : data(value), next(nullptr) {}
    };
    std::atomic<Node*> head;
    std::atomic<Node*> tail;

public:
    LockFreeQueue() {
        Node* dummy = new Node(T());
        head.store(dummy);
        tail.store(dummy);
    }

    void enqueue(T value) {
        Node* newNode = new Node(value);
        Node* oldTail;
        while (true) {
            oldTail = tail.load();
            Node* tailNext = oldTail->next;
            if (tailNext == nullptr) {
                if (oldTail->next.compare_exchange_strong(tailNext, newNode)) {
                    tail.compare_exchange_strong(oldTail, newNode);
                    return;
                }
            } else {
                tail.compare_exchange_strong(oldTail, tailNext);
            }
        }
    }

    bool dequeue(T& result) {
        Node* oldHead;
        while (true) {
            oldHead = head.load();
            Node* oldTail = tail.load();
            Node* headNext = oldHead->next;
            if (oldHead == oldTail) {
                if (headNext == nullptr) {
                    return false; // Queue is empty
                }
                tail.compare_exchange_strong(oldTail, headNext);
            } else {
                result = headNext->data;
                if (head.compare_exchange_strong(oldHead, headNext)) {
                    delete oldHead;
                    return true;
                }
            }
        }
    }
};

void test_lock_free_queue() {
    LockFreeQueue<int> queue;
    std::vector<std::thread> threads;
    for (int i = 0; i < 10; ++i) {
        threads.emplace_back([&queue, i]() {
            queue.enqueue(i);
        });
    }
    for (auto& thread : threads) {
        thread.join();
    }
    int value;
    while (queue.dequeue(value)) {
        std::cout << "Dequeued: " << value << '\n';
    }
}

int main() {
    test_lock_free_queue();
    return 0;
}
