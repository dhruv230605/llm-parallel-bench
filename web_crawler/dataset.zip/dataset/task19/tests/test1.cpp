#include <iostream>
#include "../code.cpp"

void test_race_condition() {
    LockFreeQueue<int> queue;
    std::vector<std::thread> threads;
    for (int i = 0; i < 100; ++i) {
        threads.emplace_back([&queue, i]() {
            queue.enqueue(i);
        });
    }
    for (auto& thread : threads) {
        thread.join();
    }
    int value;
    while (queue.dequeue(value)) {
        std::cout << "Dequeued: " << value << '\n';
    }
}

int main() {
    test_race_condition();
    return 0;
}
