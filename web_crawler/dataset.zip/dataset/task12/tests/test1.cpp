#include <cassert>
#include "MessageQueue.h"

void test_enqueue_dequeue() {
    char* msg = "Test Message";
    assert(atomic_queue::g_msgQueue.enqueue(msg));
    char* received;
    assert(atomic_queue::g_msgQueue.dequeue(received));
    assert(received == msg);
}

int main() {
    test_enqueue_dequeue();
    return 0;
}
