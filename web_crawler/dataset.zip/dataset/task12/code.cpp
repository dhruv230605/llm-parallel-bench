#include <iostream>
#include <atomic>
#include <thread>
#include <vector>
#include <cassert>

namespace atomic_queue {
    template <typename T, size_t Size>
    class AtomicQueue {
    private:
        T data[Size];
        std::atomic<size_t> head{0};
        std::atomic<size_t> tail{0};
    public:
        bool enqueue(const T& item) {
            size_t current_tail = tail.load();
            if ((current_tail + 1) % Size == head.load()) {
                return false; // Queue is full
            }
            data[current_tail] = item;
            tail.store((current_tail + 1) % Size);
            return true;
        }

        bool dequeue(T& item) {
            size_t current_head = head.load();
            if (current_head == tail.load()) {
                return false; // Queue is empty
            }
            item = data[current_head];
            head.store((current_head + 1) % Size);
            return true;
        }
    };

    extern AtomicQueue<char*, 1024> g_msgQueue;
}

atomic_queue::AtomicQueue<char*, 1024> atomic_queue::g_msgQueue;

int main() {
    char* msg = "Hello, World!";
    assert(atomic_queue::g_msgQueue.enqueue(msg));
    char* received;
    assert(atomic_queue::g_msgQueue.dequeue(received));
    std::cout << received << std::endl;
    return 0;
}
