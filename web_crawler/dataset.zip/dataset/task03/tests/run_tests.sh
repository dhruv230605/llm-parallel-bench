#!/bin/bash
mpic++ -o test test.cpp ../code.cpp
mpirun -np 4 ./test
