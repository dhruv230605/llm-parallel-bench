#!/bin/bash

# Compile the test
g++ -std=c++17 -o test_exclude_directory test.cpp

# Run the test
./test_exclude_directory
