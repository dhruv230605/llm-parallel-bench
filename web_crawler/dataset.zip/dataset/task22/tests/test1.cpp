#include <iostream>
#include <thread>
#include <vector>
#include "../code.cpp"

void test_exclude_directory() {
    // This test will check if the exclusion logic works correctly.
    std::vector<std::string> test_dirs = {"src", "gtest", "lib"};
    for (const auto& dir : test_dirs) {
        exclude_directory(dir);
    }
}

int main() {
    test_exclude_directory();
    return 0;
}
