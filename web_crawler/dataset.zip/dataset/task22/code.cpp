#include <iostream>
#include <vector>
#include <thread>
#include <mutex>

std::mutex mtx;
std::vector<std::string> directories = {"src", "include", "gtest"};

void exclude_directory(const std::string& dir) {
    std::lock_guard<std::mutex> lock(mtx);
    std::cout << "Excluding directory: " << dir << std::endl;
}

int main() {
    std::vector<std::thread> threads;
    for (const auto& dir : directories) {
        threads.emplace_back(exclude_directory, dir);
    }
    for (auto& th : threads) {
        th.join();
    }
    return 0;
}
