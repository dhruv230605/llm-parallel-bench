#include "../code.cpp"
#include <cassert>
#include <iostream>

void test_push_task() {
    thread_pool pool(4);
    bool result = pool.push_task(true, false, []() { std::cout << "Task executed" << std::endl; });
    assert(result == true);
}

void test_submit() {
    thread_pool pool(4);
    auto future = pool.submit(true, false, []() { std::cout << "Task executed" << std::endl; });
    assert(future.valid());
}

int main() {
    test_push_task();
    test_submit();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
