#include <iostream>
#include <thread>
#include <future>
#include <queue>
#include <functional>
#include <mutex>
#include <condition_variable>

class thread_pool {
public:
    thread_pool(size_t threads);
    template<class F, class... Args>
    bool push_task(bool checkIfFull, bool invokeIfFull, F&& task, Args&&... args);
    template<class F, class... Args>
    std::future<void> submit(bool checkIfFull, bool invokeIfFull, F&& task, Args&&... args);
    ~thread_pool();
private:
    std::vector<std::thread> workers;
    std::queue<std::function<void()>> tasks;
    std::mutex queue_mutex;
    std::condition_variable condition;
    bool stop;
};

thread_pool::thread_pool(size_t threads) : stop(false) {
    for (size_t i = 0; i < threads; ++i) {
        workers.emplace_back([this] {
            for (;;) {
                std::function<void()> task;
                {
                    std::unique_lock<std::mutex> lock(this->queue_mutex);
                    this->condition.wait(lock, [this] { return this->stop || !this->tasks.empty(); });
                    if (this->stop && this->tasks.empty())
                        return;
                    task = std::move(this->tasks.front());
                    this->tasks.pop();
                }
                task();
            }
        });
    }
}

template<class F, class... Args>
bool thread_pool::push_task(bool checkIfFull, bool invokeIfFull, F&& task, Args&&... args) {
    std::unique_lock<std::mutex> lock(queue_mutex);
    if (checkIfFull && tasks.size() >= workers.size()) {
        return false;
    }
    tasks.emplace([task, args...]() { task(args...); });
    condition.notify_one();
    return true;
}

template<class F, class... Args>
std::future<void> thread_pool::submit(bool checkIfFull, bool invokeIfFull, F&& task, Args&&... args) {
    auto packaged_task = std::make_shared<std::packaged_task<void()>>(std::bind(std::forward<F>(task), std::forward<Args>(args)...));
    std::future<void> res = packaged_task->get_future();
    if (checkIfFull && tasks.size() >= workers.size()) {
        return std::future<void>(); // return default constructed future
    }
    tasks.emplace([packaged_task]() { (*packaged_task)(); });
    condition.notify_one();
    return res;
}

thread_pool::~thread_pool() {
    {
        std::unique_lock<std::mutex> lock(queue_mutex);
        stop = true;
    }
    condition.notify_all();
    for (std::thread &worker: workers) {
        worker.join();
    }
}
