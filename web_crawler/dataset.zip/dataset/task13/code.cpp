#include <atomic>
#include <memory>
#include <iostream>

template<typename T>
class LockFreeQueue {
private:
    struct Node {
        T data;
        Node* next;
        Node(T value) : data(value), next(nullptr) {}
    };
    std::atomic<Node*> head;
    std::atomic<Node*> tail;

public:
    LockFreeQueue() {
        Node* dummy = new Node(T());
        head.store(dummy);
        tail.store(dummy);
    }

    ~LockFreeQueue() {
        while (Node* node = head.load()) {
            head.store(node->next);
            delete node;
        }
    }

    void push(T value) {
        Node* newNode = new Node(value);
        Node* oldTail = tail.load();
        oldTail->next = newNode;
        tail.store(newNode);
    }

    bool try_pop(T& result) {
        Node* oldHead = head.load();
        Node* nextNode = oldHead->next;
        if (nextNode == nullptr) {
            return false; // Queue is empty
        }
        result = nextNode->data;
        head.store(nextNode);
        delete oldHead;
        return true;
    }
};
