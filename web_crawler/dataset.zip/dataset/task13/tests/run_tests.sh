#!/bin/bash

# Compile the test
g++ -std=c++17 -o test test.cpp

# Run the test
./test
