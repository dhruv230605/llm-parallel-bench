#include <iostream>
#include <thread>
#include <vector>
#include "../code.cpp"

void producer(LockFreeQueue<int>& queue, int id) {
    for (int i = 0; i < 10; ++i) {
        queue.push(i + id * 10);
    }
}

void consumer(LockFreeQueue<int>& queue) {
    int value;
    while (true) {
        if (queue.try_pop(value)) {
            std::cout << "Consumed: " << value << std::endl;
        }
    }
}

int main() {
    LockFreeQueue<int> queue;
    std::vector<std::thread> producers;
    for (int i = 0; i < 4; ++i) {
        producers.emplace_back(producer, std::ref(queue), i);
    }
    std::thread cons(consumer, std::ref(queue));

    for (auto& p : producers) {
        p.join();
    }
    cons.detach(); // Detach consumer for continuous operation
    return 0;
}
