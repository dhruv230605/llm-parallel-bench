#include <iostream>
#include <windows.h>
#include <thread>

void threadFunction() {
    // Simulate access violation
    int* p = nullptr;
    *p = 42; // This will cause an access violation
}

void setupSEH() {
    // Set up structured exception handling
    __try {
        threadFunction();
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        std::cerr << "Access violation caught!" << std::endl;
    }
}

int main() {
    std::thread t(setupSEH);
    t.join();
    return 0;
}
