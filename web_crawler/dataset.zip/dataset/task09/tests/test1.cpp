#include <iostream>
#include <thread>
#include <windows.h>

void threadFunction();
void setupSEH();

void testSEHHandling() {
    setupSEH(); // This should catch the access violation
}

int main() {
    testSEHHandling();
    return 0;
}
