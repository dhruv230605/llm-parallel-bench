#!/bin/bash

# Compile the test
g++ -std=c++17 -o test_seh test.cpp

# Run the test
./test_seh
