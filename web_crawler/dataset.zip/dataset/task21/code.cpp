#include <iostream>
#include <vector>
#include <omp.h>
#include <stdexcept>

constexpr size_t PRIME_NUMBERS[] = {11, 17, 29, 47, 79, 127, 211, 337, 547, 887, 1433, 2311, 3739, 6053, 9791, 15858, 25667, 41539, 67213, 104729};
constexpr size_t N_PRIME_NUMBERS = sizeof(PRIME_NUMBERS) / sizeof(size_t);

size_t get_n_rehashing_buckets(const size_t n_buckets_in) {
    size_t remaining_factor = n_buckets_in;
    size_t n_rehashing_buckets = 1;
    for (size_t i = 0; i < 3; i++) {
        if (remaining_factor > PRIME_NUMBERS[N_PRIME_NUMBERS - 1]) {
            remaining_factor /= 15858;
            n_rehashing_buckets *= 15858;
        }
    }
    if (remaining_factor > PRIME_NUMBERS[N_PRIME_NUMBERS - 1]) throw std::invalid_argument("n_buckets too large");
    return n_rehashing_buckets;
}

int main() {
    size_t n_buckets = 100000;
    try {
        size_t rehashing_buckets = get_n_rehashing_buckets(n_buckets);
        std::cout << "Rehashing buckets: " << rehashing_buckets << std::endl;
    } catch (const std::invalid_argument& e) {
        std::cerr << e.what() << std::endl;
    }
    return 0;
}
