#include <iostream>
#include <cassert>
#include "../code.cpp"

void test_get_n_rehashing_buckets() {
    assert(get_n_rehashing_buckets(100) == 11);
    assert(get_n_rehashing_buckets(200) == 11);
    assert(get_n_rehashing_buckets(100000) == 15858);
    try {
        get_n_rehashing_buckets(2147483648);
        assert(false); // Should throw
    } catch (const std::invalid_argument& e) {
        assert(true); // Expected exception
    }
}

int main() {
    test_get_n_rehashing_buckets();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
