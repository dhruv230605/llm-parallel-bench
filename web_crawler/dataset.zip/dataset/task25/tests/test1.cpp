#include <gtest/gtest.h>
#include "../code.cpp"

TEST(ThreadPoolTest, EnqueueAndExecute) {
    ThreadPool pool(2);
    auto result = pool.enqueue([] { return 42; });
    EXPECT_EQ(result.get(), 42);
}

TEST(ThreadPoolTest, MultipleTasks) {
    ThreadPool pool(4);
    std::vector<std::future<int>> results;
    for (int i = 0; i < 10; ++i) {
        results.emplace_back(pool.enqueue([i] { return i; }));
    }
    for (int i = 0; i < 10; ++i) {
        EXPECT_EQ(results[i].get(), i);
    }
}
