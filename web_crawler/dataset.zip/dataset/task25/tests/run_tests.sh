#!/bin/bash
set -e

g++ -std=c++17 -pthread -o test_runner test.cpp -lgtest -lgtest_main
./test_runner
