#include <cassert>
#include <functional>
#include "../code.cpp"

void test_safe_initialize() {
    constexpr double value = safe_initialize<double>();
    assert(value == 0.0);
}

void test_hash_map() {
    HashMap<int, double> map;
    double test_value = 0.0;
    map.set(1, [&test_value](double& v) { v = 3.14; });
    assert(test_value == 3.14);
}

int main() {
    test_safe_initialize();
    test_hash_map();
    return 0;
}
