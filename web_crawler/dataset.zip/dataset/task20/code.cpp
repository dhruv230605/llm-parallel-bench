#include <iostream>
#include <functional>

template <typename T>
constexpr T safe_initialize() {
    return T(); // Ensures T is initialized properly
}

template <typename K, typename V>
class HashMap {
public:
    void set(const K& key, const std::function<void(V&)>& setter) {
        V value = safe_initialize<V>();
        setter(value);
        // Store value in the map (omitted for brevity)
    }
};

int main() {
    HashMap<int, double> map;
    map.set(1, [](double& v) { v = 3.14; });
    return 0;
}
