#include <iostream>
#include "../code.cpp"

int main() {
    std::string message = "Hello, Bitcoin!";
    std::string privateKey = "your_private_key_in_hex"; // Replace with a valid private key
    std::string signature = signMessage(message, privateKey);
    std::cout << "Signature: " << signature << std::endl;
    return 0;
}
