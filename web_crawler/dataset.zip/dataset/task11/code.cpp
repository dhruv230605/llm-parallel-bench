#include <iostream>
#include <string>
#include <openssl/sha.h>
#include <openssl/ripemd.h>
#include <openssl/ec.h>
#include <openssl/obj_mac.h>
#include <openssl/err.h>

std::string signMessage(const std::string& message, const std::string& privateKeyHex) {
    // Convert hex private key to binary
    unsigned char privateKey[32];
    for (size_t i = 0; i < 32; ++i) {
        sscanf(privateKeyHex.substr(i * 2, 2).c_str(), "%2hhx", &privateKey[i]);
    }

    // Create EC_KEY from private key
    EC_KEY* key = EC_KEY_new_by_curve_name(NID_secp256k1);
    BIGNUM* bn = BN_bin2bn(privateKey, 32, NULL);
    EC_KEY_set_private_key(key, bn);

    // Hash the message
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256(reinterpret_cast<const unsigned char*>(message.c_str()), message.size(), hash);

    // Sign the hash
    unsigned char* signature = new unsigned char[256];
    unsigned int sigLen;
    if (ECDSA_sign(0, hash, SHA256_DIGEST_LENGTH, signature, &sigLen, key) != 1) {
        ERR_print_errors_fp(stderr);
        return "";
    }

    // Convert signature to hex
    std::string signatureHex;
    for (unsigned int i = 0; i < sigLen; ++i) {
        char buf[3];
        sprintf(buf, "%02x", signature[i]);
        signatureHex += buf;
    }

    delete[] signature;
    EC_KEY_free(key);
    BN_free(bn);
    return signatureHex;
}
