#include <iostream>
#include <mpi.h>
#include <vector>
#include <thread>

void simulate_node(int rank) {
    std::cout << "Node " << rank << " is processing transactions...\n";
    // Simulate transaction processing
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
}

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);
    int world_size;
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    int world_rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

    simulate_node(world_rank);

    MPI_Finalize();
    return 0;
}
