#!/bin/bash
mpic++ -o test_simulation test.cpp ../code.cpp
mpirun -np 4 ./test_simulation
