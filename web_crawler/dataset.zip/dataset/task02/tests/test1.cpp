#include <iostream>
#include <mpi.h>

extern void simulate_node(int rank);

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);
    int world_size;
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    int world_rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

    simulate_node(world_rank);

    MPI_Finalize();
    return 0;
}
