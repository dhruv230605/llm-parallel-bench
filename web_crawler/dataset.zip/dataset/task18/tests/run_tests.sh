#!/bin/bash
set -e

g++ -std=c++17 -o test_lock_free_queue test.cpp
./test_lock_free_queue
