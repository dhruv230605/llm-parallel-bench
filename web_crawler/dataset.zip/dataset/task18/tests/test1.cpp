#include <cassert>
#include "../code.cpp"

void test_lock_free_queue() {
    LockFreeQueue<int> queue;
    queue.enqueue(10);
    queue.enqueue(20);
    int value;
    assert(queue.dequeue(value) && value == 10);
    assert(queue.dequeue(value) && value == 20);
    assert(!queue.dequeue(value)); // Queue should be empty now
}

int main() {
    test_lock_free_queue();
    return 0;
}
