#include <atomic>
#include <memory>
#include <iostream>

template <typename T>
class LockFreeQueue {
private:
    struct Node {
        T data;
        Node* next;
        Node(T value) : data(value), next(nullptr) {}
    };
    std::atomic<Node*> head;
    std::atomic<Node*> tail;

public:
    LockFreeQueue() {
        Node* dummy = new Node(T());
        head.store(dummy);
        tail.store(dummy);
    }

    ~LockFreeQueue() {
        while (Node* node = head.load()) {
            head.store(node->next);
            delete node;
        }
    }

    void enqueue(T value) {
        Node* newNode = new Node(value);
        Node* oldTail;
        while (true) {
            oldTail = tail.load();
            Node* tailNext = oldTail->next;
            if (tailNext == nullptr) {
                if (oldTail->next.compare_exchange_strong(tailNext, newNode)) {
                    tail.compare_exchange_strong(oldTail, newNode);
                    return;
                }
            } else {
                tail.compare_exchange_strong(oldTail, tailNext);
            }
        }
    }

    bool dequeue(T& result) {
        Node* oldHead;
        while (true) {
            oldHead = head.load();
            Node* oldTail = tail.load();
            Node* headNext = oldHead->next;
            if (oldHead == oldTail) {
                if (headNext == nullptr) {
                    return false; // Queue is empty
                }
                tail.compare_exchange_strong(oldTail, headNext);
            } else {
                result = headNext->data;
                if (head.compare_exchange_strong(oldHead, headNext)) {
                    delete oldHead;
                    return true;
                }
            }
        }
    }
};

int main() {
    LockFreeQueue<int> queue;
    queue.enqueue(1);
    queue.enqueue(2);
    int value;
    while (queue.dequeue(value)) {
        std::cout << value << std::endl;
    }
    return 0;
}
