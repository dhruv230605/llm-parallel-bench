#include "../code.cpp"
#include <cassert>
#include <iostream>

void testThreadPool() {
    ThreadPool pool(4);
    int result = 0;
    for (int i = 0; i < 10; ++i) {
        pool.enqueue([&result] { result++; });
    }
    std::this_thread::sleep_for(std::chrono::seconds(1)); // Wait for tasks to finish
    assert(result == 10);
    std::cout << "All tasks completed successfully!\n";
}

int main() {
    testThreadPool();
    return 0;
}
