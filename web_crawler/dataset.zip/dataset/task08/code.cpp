#include <atomic>
#include <iostream>
#include <thread>
#include <vector>

class AtomicQueue {
public:
    AtomicQueue(size_t size) : size_(size), elements_(new std::atomic<int>[size]) {}
    ~AtomicQueue() { delete[] elements_; }

    void enqueue(int value) {
        size_t index = write_index_.fetch_add(1) % size_;
        elements_[index].store(value);
    }

    int dequeue() {
        size_t index = read_index_.fetch_add(1) % size_;
        return elements_[index].load();
    }

private:
    size_t size_;
    std::atomic<int>* elements_;
    std::atomic<size_t> write_index_{0};
    std::atomic<size_t> read_index_{0};
};

void producer(AtomicQueue& queue, int id) {
    for (int i = 0; i < 10; ++i) {
        queue.enqueue(id * 10 + i);
    }
}

void consumer(AtomicQueue& queue) {
    for (int i = 0; i < 20; ++i) {
        std::cout << "Consumed: " << queue.dequeue() << '\n';
    }
}

int main() {
    AtomicQueue queue(10);
    std::thread prod1(producer, std::ref(queue), 1);
    std::thread prod2(producer, std::ref(queue), 2);
    std::thread cons(consumer, std::ref(queue));

    prod1.join();
    prod2.join();
    cons.join();

    return 0;
}
