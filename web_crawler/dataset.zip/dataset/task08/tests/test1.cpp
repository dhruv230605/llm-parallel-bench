#include "../code.cpp"
#include <cassert>
#include <thread>
#include <vector>

void test_atomic_queue() {
    AtomicQueue queue(10);
    std::vector<std::thread> producers;
    std::vector<std::thread> consumers;

    for (int i = 0; i < 5; ++i) {
        producers.emplace_back(producer, std::ref(queue), i);
    }
    for (int i = 0; i < 5; ++i) {
        consumers.emplace_back(consumer, std::ref(queue));
    }

    for (auto& p : producers) p.join();
    for (auto& c : consumers) c.join();
}

int main() {
    test_atomic_queue();
    return 0;
}
