#!/bin/bash
mpic++ -o test_bfs test.cpp ../code.cpp
mpirun -np 4 ./test_bfs
