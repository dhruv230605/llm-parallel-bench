#include <iostream>
#include <vector>
#include <mpi.h>

extern void bfs(int rank, int size, const std::vector<std::vector<int>>& graph, int start);

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    std::vector<std::vector<int>> graph = {{1, 2}, {0, 3}, {0, 3}, {1, 2}};
    bfs(rank, size, graph, 0);

    MPI_Finalize();
    return 0;
}
