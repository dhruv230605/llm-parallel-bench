#include <iostream>
#include <thread>
#include <chrono>
#include "../code.cpp"

void testGraphTraversal() {
    Graph g(5);
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 3);
    g.addEdge(1, 4);
    g.concurrentDFS(0);
    std::this_thread::sleep_for(std::chrono::seconds(1)); // Wait for threads to finish
}

int main() {
    testGraphTraversal();
    return 0;
}
