#include <iostream>
#include <vector>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>

class Graph {
public:
    Graph(int vertices);
    void addEdge(int v, int w);
    void concurrentDFS(int start);

private:
    void dfs(int v);
    std::vector<std::vector<int>> adj;
    std::vector<bool> visited;
    std::mutex mtx;
};

Graph::Graph(int vertices) : adj(vertices), visited(vertices, false) {}

void Graph::addEdge(int v, int w) {
    adj[v].push_back(w);
}

void Graph::dfs(int v) {
    std::lock_guard<std::mutex> lock(mtx);
    visited[v] = true;
    std::cout << "Visited " << v << std::endl;
    for (int i : adj[v]) {
        if (!visited[i]) {
            std::thread(&Graph::dfs, this, i).detach();
        }
    }
}

void Graph::concurrentDFS(int start) {
    dfs(start);
}

int main() {
    Graph g(5);
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 3);
    g.addEdge(1, 4);
    g.concurrentDFS(0);
    std::this_thread::sleep_for(std::chrono::seconds(1)); // Wait for threads to finish
    return 0;
}
