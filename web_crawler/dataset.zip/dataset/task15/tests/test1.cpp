#include <iostream>
#include <thread>
#include <mutex>

extern void wait_deadlock();

void test_wait_deadlock() {
    std::thread t1(wait_deadlock);
    std::thread t2(wait_deadlock);
    t1.join();
    t2.join();
    std::cout << "Test completed successfully." << std::endl;
}

int main() {
    test_wait_deadlock();
    return 0;
}
