#!/bin/bash
set -e

g++ -std=c++17 -o test_wait_deadlock test.cpp ../code.cpp
./test_wait_deadlock
