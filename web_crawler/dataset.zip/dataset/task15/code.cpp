#include <iostream>
#include <thread>
#include <mutex>

std::mutex mtx;

#ifdef __cpp_exceptions
void wait_deadlock() {
    std::lock_guard<std::mutex> lock(mtx);
    // Simulate waiting for a deadlock condition
    std::this_thread::sleep_for(std::chrono::seconds(1));
    std::cout << "Deadlock condition checked." << std::endl;
}
#endif

int main() {
    std::thread t1(wait_deadlock);
    std::thread t2(wait_deadlock);
    t1.join();
    t2.join();
    return 0;
}
