#include "../code.cpp"
#include <cassert>
#include <sstream>
#include <iostream>

void test_parallel_task() {
    std::ostringstream output;
    std::streambuf* original_cout = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());

    parallel_task(0);
    std::cout.rdbuf(original_cout);

    std::string result = output.str();
    assert(result.find("Task 0 is running") != std::string::npos);
}

int main() {
    test_parallel_task();
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
