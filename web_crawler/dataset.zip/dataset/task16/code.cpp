#include <iostream>
#include <thread>
#include <vector>

void parallel_task(int id) {
    std::cout << "Task " << id << " is running on thread " << std::this_thread::get_id() << '\n';
}

int main() {
    const int num_threads = 4;
    std::vector<std::thread> threads;
    for (int i = 0; i < num_threads; ++i) {
        threads.emplace_back(parallel_task, i);
    }
    for (auto& thread : threads) {
        thread.join();
    }
    return 0;
}
