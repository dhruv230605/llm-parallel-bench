#include <iostream>
#include <vector>
#include <thread>
#include <atomic>
#include <functional>
#include <condition_variable>
#include <queue>
#include <mutex>

class ThreadPool {
public:
    ThreadPool(size_t initial_size) : stop(false) {
        resize(initial_size);
    }

    ~ThreadPool() {
        stop = true;
        cv.notify_all();
        for (std::thread &worker : workers) {
            worker.join();
        }
    }

    void enqueue(std::function<void()> task) {
        {
            std::unique_lock<std::mutex> lock(queue_mutex);
            tasks.push(std::move(task));
        }
        cv.notify_one();
    }

    void resize(size_t new_size) {
        std::unique_lock<std::mutex> lock(queue_mutex);
        for (size_t i = 0; i < new_size; ++i) {
            workers.emplace_back([this] {
                while (true) {
                    std::function<void()> task;
                    {
                        std::unique_lock<std::mutex> lock(this->queue_mutex);
                        this->cv.wait(lock, [this] { return this->stop || !this->tasks.empty(); });
                        if (this->stop && this->tasks.empty())
                            return;
                        task = std::move(this->tasks.front());
                        this->tasks.pop();
                    }
                    task();
                }
            });
        }
    }

private:
    std::vector<std::thread> workers;
    std::queue<std::function<void()>> tasks;
    std::mutex queue_mutex;
    std::condition_variable cv;
    bool stop;
};
