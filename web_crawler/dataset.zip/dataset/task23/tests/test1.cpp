#include "../code.cpp"
#include <cassert>
#include <chrono>

void test_thread_pool() {
    ThreadPool pool(2);
    std::atomic<int> counter(0);
    for (int i = 0; i < 100; ++i) {
        pool.enqueue([&counter] { counter++; });
    }
    std::this_thread::sleep_for(std::chrono::seconds(1));
    assert(counter.load() == 100);
}

int main() {
    test_thread_pool();
    return 0;
}
