#!/bin/bash
set -e

g++ -std=c++17 -o test_thread_pool test.cpp
./test_thread_pool
