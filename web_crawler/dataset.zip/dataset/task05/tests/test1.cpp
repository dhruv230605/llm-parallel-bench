#include <iostream>
#include <thread>
#include <cassert>
#include "../code.cpp"

void test_thread_pool() {
    ThreadPool pool(2);
    int result = 0;
    pool.enqueue([&result] { result = 42; });
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    assert(result == 42);
}

int main() {
    test_thread_pool();
    std::cout << "Test passed!" << std::endl;
    return 0;
}
