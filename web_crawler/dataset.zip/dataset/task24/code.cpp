#include <iostream>
#include <vector>
#include <thread>
#include <functional>
#include <queue>
#include <condition_variable>
#include <atomic>

class ThreadPool {
public:
    ThreadPool(size_t threads);
    template<class F>
    void enqueue(F&& f);
    ~ThreadPool();
private:
    std::vector<std::thread> workers;
    std::queue<std::function<void()>> tasks;
    std::mutex queue_mutex;
    std::condition_variable condition;
    std::atomic<bool> stop;
};

ThreadPool::ThreadPool(size_t threads) : stop(false) {
    for (size_t i = 0; i < threads; ++i) {
        workers.emplace_back([this] {
            for (;;) {
                std::function<void()> task;
                {
                    std::unique_lock<std::mutex> lock(this->queue_mutex);
                    this->condition.wait(lock, [this] { return this->stop || !this->tasks.empty(); });
                    if (this->stop && this->tasks.empty())
                        return;
                    task = std::move(this->tasks.front());
                    this->tasks.pop();
                }
                task();
            }
        });
    }
}

template<class F>
void ThreadPool::enqueue(F&& f) {
    {
        std::unique_lock<std::mutex> lock(queue_mutex);
        tasks.emplace(std::forward<F>(f));
    }
    condition.notify_one();
}

ThreadPool::~ThreadPool() {
    {
        std::unique_lock<std::mutex> lock(queue_mutex);
        stop = true;
    }
    condition.notify_all();
    for (std::thread &worker: workers)
        worker.join();
}

void benchmark(int n) {
    ThreadPool pool(std::thread::hardware_concurrency());
    std::vector<std::future<void>> results;
    for (int i = 0; i < n; ++i) {
        results.emplace_back(pool.enqueue([i] {
            // Simulate work
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }));
    }
    for (auto && result: results)
        result.get();
}

int main() {
    const int num_tasks = 100;
    auto start = std::chrono::high_resolution_clock::now();
    benchmark(num_tasks);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    std::cout << "Elapsed time: " << elapsed.count() << " seconds" << std::endl;
    return 0;
}
