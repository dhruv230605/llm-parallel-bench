#!/bin/bash
set -e

g++ -std=c++17 -o test_benchmark test.cpp
./test_benchmark
