#include <iostream>
#include <future>
#include "../code.cpp"

void test_benchmark() {
    const int num_tasks = 100;
    auto start = std::chrono::high_resolution_clock::now();
    benchmark(num_tasks);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    std::cout << "Test completed in: " << elapsed.count() << " seconds" << std::endl;
}

int main() {
    test_benchmark();
    return 0;
}
