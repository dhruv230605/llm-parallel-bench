#include <cassert>
#include <future>
#include <thread>
#include <iostream>
#include "../code.cpp"

void test_multi_future() {
    multi_future mf(2);
    mf.set_future(0, std::async(std::launch::async, []() { std::this_thread::sleep_for(std::chrono::seconds(1)); }));
    mf.set_future(1, std::async(std::launch::async, []() { std::this_thread::sleep_for(std::chrono::seconds(1)); }));
    mf.wait_all();
    std::cout << "Test completed successfully." << std::endl;
}

int main() {
    test_multi_future();
    return 0;
}
