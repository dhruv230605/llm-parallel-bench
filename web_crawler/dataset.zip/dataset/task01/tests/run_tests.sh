#!/bin/bash
set -e

# Compile the code and test
g++ -std=c++17 -o test ../code.cpp test.cpp

# Run the test
./test
