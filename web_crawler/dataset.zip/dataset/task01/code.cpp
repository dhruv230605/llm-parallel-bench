#include <future>
#include <vector>
#include <iostream>
#include <thread>
#include <functional>

class multi_future {
public:
    multi_future(size_t count) : futures(count) {}

    void set_future(size_t index, std::future<void> fut) {
        futures[index] = std::move(fut);
    }

    void wait_all() {
        for (auto& fut : futures) {
            if (fut.valid()) {
                fut.wait();
            }
        }
    }

private:
    std::vector<std::future<void>> futures;
};

void example_task() {
    std::this_thread::sleep_for(std::chrono::seconds(1));
}

int main() {
    multi_future mf(3);
    for (size_t i = 0; i < 3; ++i) {
        mf.set_future(i, std::async(std::launch::async, example_task));
    }
    mf.wait_all();
    std::cout << "All tasks completed." << std::endl;
    return 0;
}
