#!/bin/bash
set -e

g++ -std=c++17 -o test ../test.cpp
./test
