#include "../code.cpp"
#include <cassert>
#include <thread>
#include <vector>

void test_enqueue_dequeue() {
    AtomicQueue<int> queue(10);
    assert(queue.enqueue(1));
    int item;
    assert(queue.dequeue(item));
    assert(item == 1);
    assert(!queue.dequeue(item)); // Queue should be empty now
}

void test_concurrent_operations() {
    AtomicQueue<int> queue(100);
    std::vector<std::thread> threads;
    for (int i = 0; i < 10; ++i) {
        threads.emplace_back([&queue]() {
            for (int j = 0; j < 10; ++j) {
                queue.enqueue(j);
            }
        });
    }
    for (auto& t : threads) {
        t.join();
    }
    int item;
    for (int i = 0; i < 100; ++i) {
        assert(queue.dequeue(item));
    }
}

int main() {
    test_enqueue_dequeue();
    test_concurrent_operations();
    return 0;
}
