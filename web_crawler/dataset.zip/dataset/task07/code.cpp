#include <atomic>
#include <vector>
#include <thread>
#include <iostream>
#include <chrono>

template<typename T>
class AtomicQueue {
private:
    std::atomic<size_t> head;
    std::atomic<size_t> tail;
    std::vector<T> buffer;

public:
    AtomicQueue(size_t size) : head(0), tail(0), buffer(size) {}

    bool enqueue(const T& item) {
        size_t current_tail = tail.load();
        if (current_tail >= buffer.size()) return false;
        buffer[current_tail] = item;
        tail.fetch_add(1);
        return true;
    }

    bool dequeue(T& item) {
        size_t current_head = head.load();
        if (current_head >= tail.load()) return false;
        item = buffer[current_head];
        head.fetch_add(1);
        return true;
    }
};

void benchmark(AtomicQueue<int>& queue, int iterations) {
    for (int i = 0; i < iterations; ++i) {
        queue.enqueue(i);
    }
}

int main() {
    const int iterations = 100000;
    AtomicQueue<int> queue(100000);
    std::thread t1(benchmark, std::ref(queue), iterations);
    std::thread t2(benchmark, std::ref(queue), iterations);

    t1.join();
    t2.join();

    int item;
    while (queue.dequeue(item)); // Drain the queue
    std::cout << "Benchmark completed." << std::endl;
    return 0;
}
